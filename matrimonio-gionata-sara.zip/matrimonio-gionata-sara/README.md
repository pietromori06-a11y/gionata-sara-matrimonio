# Mini-sito matrimonio — Gionata & Sara

Pagina statica in un solo file (`index.html`), senza framework, database, account per gli invitati o dipendenze esterne. È progettata per smartphone e desktop e include il pulsante per copiare l'IBAN.

## Pubblicazione consigliata: GitHub Pages

1. Accedi a GitHub e crea un nuovo repository pubblico, ad esempio `gionata-sara-matrimonio`.
2. Carica nella cartella principale del repository il file `index.html`.
3. Apri **Settings → Pages**.
4. In **Build and deployment**, scegli **Deploy from a branch**.
5. Seleziona il branch `main` e la cartella `/ (root)`, poi salva.
6. Attendi che GitHub Pages pubblichi il sito. L'indirizzo sarà simile a `https://NOMEUTENTE.github.io/gionata-sara-matrimonio/`.
7. Apri l'indirizzo da uno smartphone e verifica che testo, IBAN e pulsante di copia funzionino.

La pubblicazione GitHub Pages da un repository pubblico è disponibile con GitHub Free. I siti `github.io` supportano HTTPS. Considera però che la pagina sarà pubblica: chiunque abbia il collegamento potrà vedere l'IBAN. Evita di aggiungere al repository password, documenti o altri dati riservati.

## Generare il QR Code definitivo

Il QR Code va creato **solo dopo** che GitHub Pages ha assegnato e pubblicato l'indirizzo definitivo. Un QR Code statico non scade da solo, ma smette di funzionare se il sito o il suo indirizzo vengono rimossi o cambiati.

Dopo la pubblicazione, installa la dipendenza Python e lancia:

```bash
python -m pip install "qrcode[pil]"
python genera_qr.py "https://NOMEUTENTE.github.io/gionata-sara-matrimonio/"
```

Lo script genera `qr-matrimonio.png` ad alta risoluzione e `qr-matrimonio.svg` per la stampa. Prima di stampare, prova il QR Code con almeno due smartphone diversi e conserva il file del QR insieme a una copia di `index.html`.

## Modifiche future

Per cambiare il testo o le coordinate, modifica `index.html` e carica il file aggiornato nello stesso repository. Mantieni invariato il nome del repository e il percorso del sito, così il QR Code già stampato continuerà a puntare alla pagina.
