#!/usr/bin/env python3
"""Genera QR Code statici PNG e SVG per l'URL HTTPS definitivo del mini-sito."""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

try:
    import qrcode
    from qrcode.constants import ERROR_CORRECT_H
    from qrcode.image.svg import SvgPathImage
except ImportError:
    print('Dipendenza mancante. Installa con: python -m pip install "qrcode[pil]"', file=sys.stderr)
    raise SystemExit(2)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('url', help='URL HTTPS pubblico definitivo del mini-sito')
    parser.add_argument('--prefix', default='qr-matrimonio', help='Prefisso dei file da creare')
    args = parser.parse_args()

    url = args.url.strip()
    if not re.fullmatch(r'https://[^\s]+', url, flags=re.IGNORECASE):
        parser.error('Inserisci l’URL pubblico definitivo, che deve iniziare con https://')

    qr = qrcode.QRCode(
        version=None,
        error_correction=ERROR_CORRECT_H,
        box_size=18,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    png_path = Path(f'{args.prefix}.png')
    svg_path = Path(f'{args.prefix}.svg')
    qr.make_image(fill_color='#30291f', back_color='#ffffff').save(png_path)
    qr_svg = qrcode.QRCode(
        version=qr.version,
        error_correction=ERROR_CORRECT_H,
        box_size=18,
        border=4,
    )
    qr_svg.add_data(url)
    qr_svg.make(fit=False)
    qr_svg.make_image(image_factory=SvgPathImage, fill_color='#30291f', back_color='#ffffff').save(svg_path)

    print(f'URL codificato: {url}')
    print(f'Creato: {png_path.resolve()}')
    print(f'Creato: {svg_path.resolve()}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
